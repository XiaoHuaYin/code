"""
this is for refined prediction of:
lungs, airways, airways vessels, heart
"""

import Tool_Functions.Functions as Functions
import numpy as np
import prediction.predict_rescaled as predictor

